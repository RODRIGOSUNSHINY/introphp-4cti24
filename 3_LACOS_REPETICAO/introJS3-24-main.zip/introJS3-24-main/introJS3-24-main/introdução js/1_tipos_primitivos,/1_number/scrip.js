const texto1 = "kaike cupin";
const texto2 = "gabizin";

const texto# = "O gabizin foi no banheiro";

console.log(texto1);
console.log(texto2);
console.log(texto3);

console.log(texto2 + texto3);